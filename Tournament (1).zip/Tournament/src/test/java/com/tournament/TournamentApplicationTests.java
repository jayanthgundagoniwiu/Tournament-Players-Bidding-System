package com.tournament;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TournamentApplicationTests {

	@Test
	void contextLoads() {
	}

}
